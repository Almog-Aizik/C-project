#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "cards.h"
#include "save.h"
#include "game.h"

#endif
