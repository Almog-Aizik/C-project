#ifndef SAVE_H
#define SAVE_H

#include "main.h"

int load_save();
int save_to_file(int data);

#endif